# -*- coding: utf-8 -*-
import xbmc,time,xbmcaddon,os,requests,xbmcgui,re,logging,threading,urllib,json,datetime

try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

Addon = xbmcaddon.Addon()

global g_item,g_timer
g_timer=0
g_item={}

global settings
settings={}

from resources.scrapers.globals import *

from resources.done import cache
global current_list_item,list_index
list_index=999
current_list_item=''
from default import nextup,show_sources,done_nextup,movie_wall_new,fav_mv,ClearCache#,last_viewed
# from hebdub_movies import update_now
# from kidstv import update_now_tv
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
        
def post_trakt(path,data=None, with_auth=True):
    import urllib
    API_ENDPOINT = "https://api-v2launch.trakt.tv"
    CLIENT_ID = "8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6"
    SETTING_TRAKT_ACCESS_TOKEN = "trakt_access_token"
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': CLIENT_ID
    }


    
    if with_auth:
           
            token =unicode( Addon.getSetting(SETTING_TRAKT_ACCESS_TOKEN))
            headers.update({'Authorization': 'Bearer %s' % token})
            
        
            return requests.post("{0}/{1}".format(API_ENDPOINT, path), json=(data), headers=headers).content
def similar(w1, w2):
    from difflib import SequenceMatcher
    
    s = SequenceMatcher(None, w1, w2)
    return int(round(s.ratio()*100))
def normalizeString(str):
    import unicodedata
    return unicodedata.normalize(
        'NFKD', unicode(unicode(str, 'utf-8'))
    ).encode('utf-8', 'ignore')
def read_firebase(table_name):
    from resources.modules.firebase import firebase
    firebase = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = firebase.get('/', None)
    if table_name in result:
        return result[table_name]
    else:
        return {}
# write_firebase(name,tmdb,season,episode,playtime,total,free,table_name,'0','0')
def write_firebase(original_title,id,season,episode,g_timer,g_item_total_time,free,table_name):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)


    result = fb_app.post(table_name, {'original_title':original_title,'tmdb':id,'season':season,'episode':episode,'playtime':g_timer,'total':g_item_total_time,'free':free})
    return 'OK'
def delete_firebase(table_name,record):
    from resources.modules.firebase import firebase
    fb_app = firebase.FirebaseApplication('https://%s-default-rtdb.firebaseio.com'%Addon.getSetting("firebase"), None)
    result = fb_app.delete(table_name, record)
    return 'OK'
class MainMonitor(xbmc.Monitor):
    
    def __init__(self):
        super(MainMonitor, self).__init__()

    def onSettingsChanged(self):
        global settings
        Addon = xbmcaddon.Addon('plugin.video.torrent')
        logging.warning('Settings changed')
        settings['save_time']==Addon.getSetting('save_time')
        settings['fav_search_f_tv']==Addon.getSetting('fav_search_f_tv')
        settings['fav_servers_en_tv']==Addon.getSetting('fav_servers_en_tv')
        settings['fav_servers_tv']==Addon.getSetting('fav_servers_tv')
        settings['google_server_tv']==Addon.getSetting('google_server_tv')
        settings['rapid_server_tv']==Addon.getSetting('rapid_server_tv')
        settings['direct_server_tv']==Addon.getSetting('direct_server_tv')
        settings['heb_server_tv']==Addon.getSetting('heb_server_tv')
        settings['auto_nextup']==Addon.getSetting('auto_nextup')
        settings['nextup_style']==Addon.getSetting('nextup_style')
        settings['all_t']==Addon.getSetting('all_t')
        settings['play_nextup_wait']==Addon.getSetting('play_nextup_wait')
        settings['fast_play2_tv']==Addon.getSetting('fast_play2_tv')
        logging.warning('Style')
        logging.warning(settings['nextup_style'])
        xbmc.executebuiltin('Container.Refresh')
        
class AutoSubsPlayer(xbmc.Player):
    global __settings__,__addon__,MyAddon,MyScriptID

    def __init__(self, *args, **kwargs):
        global g_item,g_timer
        xbmc.Player.__init__(self)
        g_timer=0
        self.run = True
        g_item={}
        try:
            

            self.dbcon = database.connect(cacheFile)
            self.dbcur = self.dbcon.cursor()
            self.dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""tmdb TEXT, ""season TEXT, ""episode TEXT,""playtime TEXT,""total TEXT, ""free TEXT);" % 'playback')
            self.dbcon.commit()
            self.dbcur.close()
            self.dbcon.close()
            
        except Exception as e:
            import linecache,sys
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)

            logging.warning('ERROR IN DB:'+str(lineno)+str(e))
            try:
                self.dbcur.close()
                self.dbcon.close()
                
            except:
                pass
            
    def onPlayBackEnded(self):
        global g_item,g_timer
        self.dbcon = database.connect(cacheFile)
        self.dbcur = self.dbcon.cursor()
        logging.warning("Stopped")
        logging.warning("player Time:")
        table_name='playback_torrent'
        if 'tmdb' in g_item:
            if len(g_item['tmdb'])>1 or len(g_item['imdb'])>1:
              if g_item['tmdb']!='%20':
                logging.warning(g_timer)
                logging.warning('Playback Ended')
                #g_timer=g_item['totaltime']
                logging.warning(g_item)
                if g_item['episode']==' ' or g_item['episode']=='':
                    g_item['episode']='0'
                if g_item['season']==' ' or g_item['season']=='':
                    g_item['season']='0'
                self.dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(g_item['tmdb'],str(g_item['season']),str(g_item['episode'])))
                match = self.dbcur.fetchall()
                logging.warning(match)
                
                if match==None:
                  self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),g_item['imdb']))
                  self.dbcon.commit()

                  # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '5')))
                  if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                    all_firebase=read_firebase(table_name)
                    write_fire=True
                    for items in all_firebase:
                  
                        if all_firebase[items]['original_title']==g_item['title']:
                         if all_firebase[items]['season']==g_item['season']:
                          if all_firebase[items]['episode']==g_item['episode']:

                            delete_firebase(table_name,items)
                            #write_fire=False
                            break
                    if write_fire:
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '5')))
                        write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)
                else:
                   if len(match)>0:
                    name,timdb,season,episode,playtime,totaltime,free=match[0]
                    if str(g_timer)!=playtime:
                        self.dbcur.execute("UPDATE playback SET playtime='%s' where tmdb='%s' and  season='%s' and episode='%s'"%(str(g_timer),g_item['tmdb'],str(g_item['season']),str(g_item['episode'])))
                        self.dbcon.commit()
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '6')))
                        if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                            all_firebase=read_firebase(table_name)
                            write_fire=True
                            for items in all_firebase:
                          
                                if all_firebase[items]['original_title']==name:
                                 if all_firebase[items]['season']==g_item['season']:
                                  if all_firebase[items]['episode']==g_item['episode']:

                                    delete_firebase(table_name,items)
                                    #write_fire=False
                                    break
                            if write_fire:
                                # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '6')))
                                write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)
                   else:
                        self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),g_item['imdb']))
                        self.dbcon.commit()
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '9')))
                        if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                            all_firebase=read_firebase(table_name)
                            write_fire=True
                            for items in all_firebase:
                          
                                if all_firebase[items]['original_title']==name:
                                 if all_firebase[items]['season']==g_item['season']:
                                  if all_firebase[items]['episode']==g_item['episode']:

                                    delete_firebase(table_name,items)
                                    #write_fire=False
                                    break
                            if write_fire:
                                # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '9')))
                                write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)
                    
            else:
                logging.warning('No IMDB')
                # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '4')))
            try:
            
                self.dbcur.close()
                self.dbcon.close()
                
            except:
                pass
        g_item={}
        self.run = True
        g_timer=0
    def onPlayBackStopped(self):
        global g_item,g_timer
        self.dbcon = database.connect(cacheFile)
        self.dbcur = self.dbcon.cursor()
        logging.warning("Stopped")
        logging.warning("player Time:")
        table_name='playback_torrent'
        if 'tmdb' in g_item:
            if len(g_item['tmdb'])>1 or len(g_item['imdb'])>1:
              if g_item['tmdb']!='%20':
                logging.warning(g_timer)
                logging.warning(g_item)
                if g_item['episode']==' ' or g_item['episode']=='':
                    g_item['episode']='0'
                if g_item['season']==' ' or g_item['season']=='':
                    g_item['season']='0'
                self.dbcur.execute("SELECT * FROM playback where tmdb='%s' and season='%s' and episode='%s'"%(g_item['tmdb'],str(g_item['season']),str(g_item['episode'])))
                match = self.dbcur.fetchall()
                logging.warning(match)

                if match==None:
                  self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),g_item['imdb']))
                  self.dbcon.commit()
                  # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '1')))
                  if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                    all_firebase=read_firebase(table_name)
                    write_fire=True
                    for items in all_firebase:
                  
                        if all_firebase[items]['original_title']==g_item['title']:
                         if all_firebase[items]['season']==g_item['season']:
                          if all_firebase[items]['episode']==g_item['episode']:

                            delete_firebase(table_name,items)
                            #write_fire=False
                            break
                    if write_fire:
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '1')))
                        write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)

                else:
                   if len(match)>0:
                    name,timdb,season,episode,playtime,totaltime,free=match[0]
                    if str(g_timer)!=playtime:
                        self.dbcur.execute("UPDATE playback SET playtime='%s' where tmdb='%s' and  season='%s' and episode='%s'"%(str(g_timer),g_item['tmdb'],str(g_item['season']),str(g_item['episode'])))
                        self.dbcon.commit()
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '2')))
                        if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                            all_firebase=read_firebase(table_name)
                            write_fire=True
                            for items in all_firebase:
                          
                                if all_firebase[items]['original_title']==name:
                                 if all_firebase[items]['season']==g_item['season']:
                                  if all_firebase[items]['episode']==g_item['episode']:

                                    delete_firebase(table_name,items)
                                    #write_fire=False
                                    break
                            if write_fire:
                                # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '2')))
                                write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)

                   else:
                        self.dbcur.execute("INSERT INTO playback Values ('%s','%s','%s','%s','%s','%s','%s');" %  (g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),g_item['imdb']))
                        self.dbcon.commit()
                        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '3')))
                        if Addon.getSetting("sync_mod")=='true' and Addon.getSetting("sync_movie")=='true':
                            all_firebase=read_firebase(table_name)
                            write_fire=True
                            for items in all_firebase:
                          
                                if all_firebase[items]['original_title']==g_item['title']:
                                 if all_firebase[items]['season']==g_item['season']:
                                  if all_firebase[items]['episode']==g_item['episode']:

                                    delete_firebase(table_name,items)
                                    #write_fire=False
                                    break
                            if write_fire:
                                # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', '3')))
                                write_firebase(g_item['title'],g_item['tmdb'],g_item['season'],g_item['episode'],str(g_timer),str(g_item['totaltime']),'',table_name)
            else:
                logging.warning('No IMDB')
            try:
            
                self.dbcur.close()
                self.dbcon.close()
                
            except:
                pass
        g_item={}
        self.run = True
        g_timer=0
        logging.warning(current_list_item)
        if '-KIDSSECTION-' in current_list_item:
            logging.warning('Refreshing')
            xbmc.executebuiltin('Container.Refresh')
    def onPlayBackStarted(self):
        g_timer=0
      
            


def check_pre(saved_name,all_subs):
       release_names=['bluray','hdtv','dvdrip','bdrip','web-dl']
       array_original=list(saved_name)
       array_original=[line.strip().lower() for line in array_original]
       array_original=[(x) for x in array_original if x != '']
       highest=0
       for items in all_subs:
           array_subs=list(items)
          
           array_subs=[line.strip().lower() for line in array_subs]
           array_subs=[str(x).lower() for x in array_subs if x != '']
           
     
           for item_2 in release_names:
           
            if item_2 in array_original and item_2 in array_subs:
              array_original.append(item_2)
              array_original.append(item_2)
              array_original.append(item_2)
              array_subs.append(item_2)
              array_subs.append(item_2)
              array_subs.append(item_2)
    
     
           precent=similar(array_original,array_subs)
           
           if precent>=highest:
             highest=precent
       return highest
def fix_q(quality):
    f_q=100
    if '2160' in quality:
      f_q=1
    if '1080' in quality:
      f_q=2
    elif '720' in quality:
      f_q=3
    elif '480' in quality:
      f_q=4
    elif 'hd' in quality.lower() or 'hq' in quality.lower():
      f_q=5
    elif '360' in quality or 'sd' in quality.lower():
      f_q=6
    elif '240' in quality:
      f_q=7
    return f_q




logging.warning('Nextup Service Started')

done_p=0
marked_trk=0
counter_no_play=0
START=True
def SetTimer(delta):
    return datetime.datetime.now() + datetime.timedelta(seconds=delta)
    
# Interval in sec
day_in_sec=60*60*12
# wallInterval = int(Addon.getSetting("refresh_wall"))*60*60
every_day_in_sec=SetTimer(day_in_sec)
# wallTimer = SetTimer(wallInterval)
enable_wall=False
if Addon.getSetting("wall_en")=='true':
    enable_wall=True
monitor = xbmc.Monitor()
player_monitor = AutoSubsPlayer()
monitor=MainMonitor()
logging.warning('!!!!!!!!!!!!!!!!!!Start Victory service!!!!!!!!!!!!!!!!!!')
def post_trk(id,season,episode):
    if len(id)>1 and id!='%20':
         if season!=None and season!="%20":
           '''
           logging.warning('tv')
           logging.warning(imdb_id)
           url_pre='http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en'%imdb_id.replace('tt','')
           html2=requests.get(url_pre).content
           pre_tvdb = str(html2).split('<seriesid>')
           if len(pre_tvdb) > 1:
                tvdb = str(pre_tvdb[1]).split('</seriesid>')
           logging.warning(tvdb)
           '''
           season_t, episode_t = int('%01d' % int(season)), int('%01d' % int(episode))
           
           i = (post_trakt('/sync/history', data={"shows": [{"seasons": [{"episodes": [{"number": episode_t}], "number": season_t}], "ids": {"tmdb": id}}]}))
           logging.warning('TRK')
           logging.warning(i)
         else:
           
           i = (post_trakt('/sync/history',data= {"movies": [{"ids": {"tmdb": id}}]}))
settings['save_time']=Addon.getSetting('save_time')
settings['fav_search_f_tv']=Addon.getSetting('fav_search_f_tv')
settings['fav_servers_en_tv']=Addon.getSetting('fav_servers_en_tv')
settings['fav_servers_tv']=Addon.getSetting('fav_servers_tv')
settings['google_server_tv']=Addon.getSetting('google_server_tv')
settings['rapid_server_tv']=Addon.getSetting('rapid_server_tv')
settings['direct_server_tv']=Addon.getSetting('direct_server_tv')
settings['heb_server_tv']=Addon.getSetting('heb_server_tv')
settings['auto_nextup']=Addon.getSetting('auto_nextup')
settings['nextup_style']=Addon.getSetting('nextup_style')
settings['all_t']=Addon.getSetting('all_t')
settings['play_nextup_wait']=Addon.getSetting('play_nextup_wait')
settings['fast_play2_tv']=Addon.getSetting('fast_play2_tv')
#ClearCache()
strings = time.strftime("%Y,%m,%d,%H,%M,%S")
t = strings.split(',')
numbers = [ int(x) for x in t ]
pre_date=numbers[2]
while not monitor.abortRequested():
 
    if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            break
    timenow = SetTimer(1)
    if enable_wall:
        
        if wallTimer < timenow or START:
            thread=[]
       
            thread.append(Thread(movie_wall_new,True))
                
            
            thread[0].start()
    
    if 0:#every_day_in_sec < timenow or START:
        dbcon_new = database.connect(cacheFile)
        dbcur_new = dbcon_new.cursor()
        dbcur_new.execute("CREATE TABLE IF NOT EXISTS %s ( ""data TEXT,""new TEXT,""free TEXT);" % 'last_viewed_last')
        dbcon_new.commit()
        x,all_d=last_viewed('tv',silent=True,dbcur=dbcur_new,dbcon=dbcon_new)

        dbcur_new.execute("SELECT * FROM last_viewed_last")
        match_new = dbcur_new.fetchone()
        if match_new==None:
            dbcur_new.execute("INSERT INTO last_viewed_last Values ('%s','%s','%s');" %  (all_d,'yes',''))
            dbcon_new.commit()
        else:
            all_d_new,resu_all_d,empty_free=match_new
            if all_d_new!=all_d:
                dbcur_new.execute("DELETE from last_viewed_last")
                
                dbcur_new.execute("INSERT INTO last_viewed_last Values ('%s','%s','%s');" %  (all_d,'yes',''))
                dbcon_new.commit()
                logging.warning('New New')
        dbcur_new.close()
        dbcon_new.close()
    START=False
    strings = time.strftime("%Y,%m,%d,%H,%M,%S")
    t = strings.split(',')
    numbers = [ int(x) for x in t ]
    # if numbers[3]==int(Addon.getSetting("update_kids")) and numbers[2]!=pre_date:
        # logging.warning('Updating now Hebdub')
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'מעדכן מדובבים')))
        # pre_date=numbers[2]
        # update_now()
        # update_now_tv()
        # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', 'הכל מעודכן')))
    if xbmc.Player().isPlaying():
        if g_timer==0:
            
                g_item={}
                g_item['totaltime']=0
                g_item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle")).replace("%20"," ")
                g_item['season'] = str(xbmc.getInfoLabel("VideoPlayer.Season"))
                g_item['episode'] = str(xbmc.getInfoLabel("VideoPlayer.Episode"))  
                imdb_id = normalizeString(xbmc.getInfoLabel("VideoPlayer.IMDBNumber"))  # try to get original title
                logging.warning('writer:'+str(xbmc.getInfoLabel("VideoPlayer.Writer ")))
                if str(xbmc.getInfoLabel("VideoPlayer.Writer "))=='%20' or len(str(xbmc.getInfoLabel("VideoPlayer.Writer ")))<2:
                    saved_icon=g_item['title']
                else:
                    saved_icon=str(xbmc.getInfoLabel("VideoPlayer.Writer "))
                g_item['tmdb']=saved_icon
                if 'tt' not in imdb_id:
                    imdb_id_tmp=xbmc.getInfoLabel("VideoPlayer.Genre") 
                    if imdb_id_tmp.startswith('tt'):
                      imdb_id = imdb_id_tmp
                g_item['imdb']=imdb_id
        try:
            g_timer=xbmc.Player().getTime()
            g_item['totaltime']=xbmc.Player().getTotalTime()
        except:
            pass
        counter_no_play=0
        
        
        try:
            time_to_window=int(Addon.getSetting("window"))
        except:
            time_to_window=30
        try:
            time_to_window_movie=int(Addon.getSetting("window_movie"))
        except:
            time_to_window_movie=30
        current_list_item=(xbmc.getInfoLabel("VideoPlayer.Plot"))
        
     
        
        if '_from_victory_' in current_list_item and '-KIDSSECTION-' not in current_list_item and '__aceplay__' not in current_list_item:
           try:
            
            time_left=xbmc.Player().getTotalTime()-xbmc.Player().getTime()
           
            if xbmc.Player().getTotalTime()>600:
                avg=(xbmc.Player().getTime()*100)/xbmc.Player().getTotalTime()
                time_to_save_trk=int(Addon.getSetting("time_to_save"))
                if Addon.getSetting("use_trak")=='true' and avg>time_to_save_trk and marked_trk==0:
                     dbcon_new = database.connect(cacheFile)
                     dbcur_new = dbcon_new.cursor()
                     dbcur_new.execute("SELECT * FROM sources")

                     match = dbcur_new.fetchone()
                     dbcur_new.close()
                     dbcon_new.close()
                 
                     name,url,icon,image,plot,year,season,episode,original_title,heb_name,show_original_year,eng_name,isr,id=match
                     thread=[]
                     thread.append(Thread(post_trk,id,season,episode))
        
    
                     thread[0].start()
                     
                     marked_trk=1
            
           
            if time_left<time_to_window_movie and time_left>0  and xbmc.Player().getTotalTime()>600:#only if longer then 10min
                
                
                if Addon.getSetting('nextup_movie')=='true' and done_nextup_movie==0:
                 reco=g_item['tmdb']
                 reco=unicode(reco, 'utf-8')     
                 if (g_item['season']==' ' or g_item['season']=='') and reco:
                     window = fav_mv('plugin.video.torrent',g_item['tmdb'])
                     window.doModal()

                     del window
                    
                    
                     done_nextup_movie=1
                
            
                     
            if time_left<time_to_window and time_left>0  and xbmc.Player().getTotalTime()>600:#only if longer then 10min
                if 'ערוץ' not in current_list_item:
                    result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.GetItems", "params": { "properties": [ "showlink", "showtitle", "season", "title", "artist" ], "playlistid": 1}, "id": 1}')

                    j_list=json.loads(result)
                    if 'items' in (j_list['result']):
                        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                        playlist.clear()
                        result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": { "playlistid": 0 }, "id": 1}')
                        logging.warning('clearing playlist')
                
                if Addon.getSetting('nextup')=='true' and done_nextup==0:
                 
                 #xbmc.executebuiltin((u'Notification(%s,%s)' % ('Nextup Runing', str(time_to_window)+'_'+str(time_left))).encode('utf-8'))
                 dbcon_new = database.connect(cacheFile)
                 dbcur_new = dbcon_new.cursor()
                 logging.warning('Style in')
                 logging.warning(settings['nextup_style'])
                 nextup(dbcur_new,settings)
                 dbcur_new.close()
                 dbcon_new.close()
                 done_nextup=1
                
            if  done_p==0:
            
                if xbmc.getCondVisibility("Player.Paused")==True :
                     done_p=1
                     xbmc.sleep(1000)
                     windoid=xbmcgui.getCurrentWindowDialogId()
                    
                     
                     if Addon.getSetting('show_p2')=='true' and windoid!=10101 and windoid!=10153:
                       
                         show_sources()
                     
                     
            if xbmc.getCondVisibility("Player.Paused")==False :
                   done_p=0
           
           except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)

            logging.warning('ERROR IN NEXTUP:'+str(lineno)+str(e))
            logging.warning('inline:'+line)
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('שגיאה', str(e))).encode('utf-8'))
            done_nextup=1
            marked_trk=1
            
            pass
           
        
    else:
       
       if counter_no_play<10:
            counter_no_play+=1
       
       if counter_no_play==5:
        if 'ערוץ' not in current_list_item and '_from_victory_' in current_list_item:
            result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.GetItems", "params": { "properties": [ "showlink", "showtitle", "season", "title", "artist" ], "playlistid": 1}, "id": 1}')

            j_list=json.loads(result)
            
            if 'items' in (j_list['result']):
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Playlist.Clear", "params": { "playlistid": 0 }, "id": 1}')
              
       done_nextup=0
       done_nextup_movie=0
       marked_trk=0
       current_list_item=''
       
    xbmc.sleep(1000)
del player_monitor
               
                             